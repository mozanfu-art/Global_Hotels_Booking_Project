<?php
include 'db-connect.php';
session_start();


if (!isset($_SESSION['UserID'])) {
    header("Location: ../sign-home/login.php");
    exit();
}

$userID = $_SESSION['UserID']; 


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$reservationSql = "SELECT * FROM reservations WHERE UserID = ? ORDER BY ReservationID DESC LIMIT 1";
$reservationStmt = $conn->prepare($reservationSql);

if ($reservationStmt === false) {
    die('MySQL prepare error: ' . $conn->error);
}

$reservationStmt->bind_param("i", $userID);
$reservationStmt->execute();
$reservationResult = $reservationStmt->get_result();

if ($reservationResult->num_rows > 0) {
    $reservation = $reservationResult->fetch_assoc();
} else {
    die("No reservations found.");
}


$userSql = "SELECT * FROM users WHERE UserID = ?";
$userStmt = $conn->prepare($userSql);

if ($userStmt === false) {
    die('MySQL prepare error: ' . $conn->error);
}

$userStmt->bind_param("i", $userID);
$userStmt->execute();
$userResult = $userStmt->get_result();

if ($userResult->num_rows > 0) {
    $user = $userResult->fetch_assoc();
} else {
    die("User not found.");
}


$reservationStmt->close();
$userStmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fffbf0; 
            margin: 0;
            padding: 0;
            color: #004d40; 
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .header {
            background-color: #004d40;
            color: #ffffff;
            padding: 10px 20px; 
            position: relative;
            display: flex;
            align-items: center;
        }

        .header .back-arrow {
            position: absolute;
            left: 20px;
        }

        .header .home-link {
            position: absolute;
            right: 20px; 
            top: 50%;
            transform: translateY(-50%);
            color: #ffffff;
            font-weight: bold;
        }

        .header h1 {
            flex-grow: 1;
            text-align: center;
            margin: 0;
            font-size: 1.5em; 
        }

        .section {
            text-align: center;
        }

        .details {
            background-color: #004d40;
            color: #ffffff;
            font-size: 1.3em;
            text-align: left;
            position: relative;
            margin: 1em;
            padding: 5px;
            font-family: Cambria;
            border: 1px solid #fff;
        }

        .yellow-bg {
            background: #fef5e7;
        }

        footer {
            background-color: #004d40;
            color: white;
            text-align: center;
            position: relative; 
            margin-top: auto; 
            width: 100%;
        }
    </style>
</head>
</head>
<body>
    <div class="header">
        <h1>Booking Confirmation</h1>
        <a href="../sign-home/Home-(HB).html" class="home-link">Home</a>
    </div>
    <div class="section">
        <h3>Your reservation is confirmed!</h3>
    </div>
    <div class="msg">
        <p><b>Hi <?php echo $user['FName'] . ' ' . $user['LName']; ?>,</b></p>
        <p class="text-msg">Thank you for choosing our app,<br> 
            after your staying you will be invited to
            provide a review about your experience at the hotel. </p>
    </div>
    <div class="details">
        <label>Reservation Details</label>
    </div>
    <table>
        <tr>
            <td class="yellow-bg">Lead Guest Name:</td>
            <td><?php echo $user['FName'] . ' ' . $user['LName']; ?></td>
        </tr>
        <tr>
            <td class="yellow-bg">Hotel Name:</td>
            <td><?php
            // Fetch hotel name using HotelID from reservation
            $hotelID = $reservation['HotelID'];
            $hotelSql = "SELECT Hotel_name FROM hotels WHERE HotelID = ?";
            $hotelStmt = $conn->prepare($hotelSql);
            $hotelStmt->bind_param("i", $hotelID);
            $hotelStmt->execute();
            $hotelResult = $hotelStmt->get_result();
            $hotel = $hotelResult->fetch_assoc();
            echo $hotel['Hotel_name'];
            ?></td>
        </tr>
        <tr>
            <td class="yellow-bg">Room Type:</td>
            <td><?php echo $reservation['RoomTypes']; ?></td>
        </tr>
        <tr>
            <td class="yellow-bg">Number of Guests:</td>
            <td><?php echo $reservation['Adults']; ?> adults, <?php echo $reservation['Children']; ?> children</td>
        </tr>
        <tr>
            <td class="yellow-bg">Number of Rooms:</td>
            <td><?php echo $reservation['NumberOfRooms']; ?> Room</td>
        </tr>
        <tr>
            <td class="yellow-bg">Check-In Date:</td>
            <td><?php echo $reservation['CheckIn_date']; ?></td>
        </tr>
        <tr>
            <td class="yellow-bg">Check-Out Date:</td>
            <td><?php echo $reservation['CheckOut_Date']; ?></td>
        </tr>
    </table>
    <div class="details">
        <label>Payment Details</label>
    </div>
    <table>
        <tr>
            <td class="yellow-bg">1 room x2 nights</td>
            <td><?php echo $reservation['Amount']; ?></td>
        </tr>
        <tr>
            <td class="yellow-bg">Other Charges</td>
            <td>0</td>
        </tr>
        <tr>
            <td class="yellow-bg">Total Charge</td>
            <td><?php echo $reservation['Amount']; ?></td>
        </tr>
        <tr>
            <td class="yellow-bg">Paid with credit card</td>
            <td>xxxxxxxxx7890</td>
        </tr>
    </table>
    <div class="details">
        <label>Cancellation Policy</label>
    </div>
    <table>
        <tr>
            <td class="yellow-bg">This booking is non-refundable.</td>
        </tr>
    </table>
    <a href="../confirmation-reviews-feedbacks/feedback.html" class="reviews-policy-button">
        Give our app a feedback?
    </a>
    <footer>
        <p>&copy; 2025 Hotels Booking. All rights reserved.</p>
    </footer>
</body>
</html>